package org.apache.ibatis.session;

public enum AutoMappingBehavior {
  NONE,PARTIAL,FULL
}
