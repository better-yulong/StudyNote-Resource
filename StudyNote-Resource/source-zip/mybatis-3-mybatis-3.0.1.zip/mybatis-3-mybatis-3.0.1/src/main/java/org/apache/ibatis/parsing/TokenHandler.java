package org.apache.ibatis.parsing;

public interface TokenHandler {
  String handleToken(String content);
}

