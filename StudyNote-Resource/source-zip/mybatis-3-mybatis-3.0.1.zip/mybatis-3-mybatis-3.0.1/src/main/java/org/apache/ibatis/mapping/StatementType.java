package org.apache.ibatis.mapping;

public enum StatementType {
  STATEMENT, PREPARED, CALLABLE
}
