package org.apache.ibatis.executor;

public enum ExecutionPlaceholder {
  EXECUTION_PLACEHOLDER
}
