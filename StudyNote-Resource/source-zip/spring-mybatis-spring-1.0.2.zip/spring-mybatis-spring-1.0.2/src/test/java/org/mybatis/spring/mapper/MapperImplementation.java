package org.mybatis.spring.mapper;

/**
 * @version $Id$
 */
// implementation of MapperInterface to test conflicting types
final class MapperImplementation implements MapperInterface {
    public void method() {};
}
